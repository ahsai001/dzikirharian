# Dzikir Harian

* Aplikasi Dzikir Harian mengandung bacaan dzikir seperti dzikir pagi & petang, dzikir setelah shalat, manfaat dzikirnya & referensi dzikirnya.

* Aplikasi ini disertai pula dengan audio/suara dzikirnya serta dengan adanya reminder/pengingat waktu untuk dzikir pagi dan petang, sehingga memudahkan kita untuk merutinkan membacanya setiap hari.

* Selain itu, aplikasi ini juga disertai dengan dalil-dalil yang melandasinya, sehingga semakin yakinlah kita untuk membacanya.

* Aplikasi ini dibuat untuk memudahkan penggunanya untuk jauh lebih mudah membaca dan menghafal dzikir harian berdasarkan Al-Quran dan hadits Shahih (hadits yang pasti datangnya dari Rasullullah Shallallahu ‘alaihi wa sallam)

Currently available on the Play store.

[![Play Store Badge](https://developer.android.com/images/brand/en_app_rgb_wo_60.png)](https://play.google.com/store/apps/details?id=com.zaitunlabs.dzikirharian)



