package com.zaitunlabs.dzikirharian.constants;

public class Constanta {
    public static final String ACTION_MANAGE_DZIKIR_REMINDER = "com.zaitunlabs.dzikirharian.action.MANAGGE_DZIKIR_REMINDER";
}
