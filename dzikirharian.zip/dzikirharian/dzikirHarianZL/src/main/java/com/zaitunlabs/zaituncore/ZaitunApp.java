package com.zaitunlabs.zaituncore;

import com.ahsailabs.alcore.api.APIConstant;
import com.ahsailabs.alutils.DebugUtil;
import com.zaitunlabs.zlcore.core.BaseApplication;

public class ZaitunApp extends BaseApplication {
	@Override
	public void onCreate() {
		APIConstant.setApiAppid("5");
		//APIConstant.setApiKey("dhrerwer12414543kfkllm");
		APIConstant.setApiVersion("v1");
		DebugUtil.setDebugingLevel(DebugUtil.VERBOSE_LEVEL);
		super.onCreate();
	}

}
